﻿using System;
using System.Threading.Tasks;
using WildApp.Data;

namespace WildApp.Domain
{
    public class Controllers
    {
        public string DatabasePath { get; } = "";

        private readonly WeatherService weatherService;
        private readonly FakeAPI waterService;

        public Controllers()
        {
            weatherService = new WeatherService();
            waterService = new FakeAPI();
        }

        public void ManageApp()
        {
            // Hier könnte später allgemeine App-Logik rein.
        }

        public void Save(string database)
        {
            // Hier könnte später Speichern in Datei/Datenbank rein.
        }

        public void Load(string database)
        {
            // Hier könnte später Laden aus Datei/Datenbank rein.
        }

        public async Task<(double temp, double wind)> UpdateWeather(double lat, double lon)
        {
            await weatherService.LoadFromAPI(lat, lon);

            return (
                weatherService.GetTemperature(),
                weatherService.GetWind()
            );
        }

        public async Task<WaterTest> GetFakeWaterTest()
        {
            WaterTest result = await waterService.GetFakeWaterData();
            return result;
        }

        public async Task<WaterTest> GetRandomWaterTest()
        {
            WaterTest result = await waterService.GetRandomWaterData();
            return result;
        }

        public string GetWaterStatus(WaterTest waterTest)
        {
            return waterTest.GetQualityStatus();
        }
    }
}