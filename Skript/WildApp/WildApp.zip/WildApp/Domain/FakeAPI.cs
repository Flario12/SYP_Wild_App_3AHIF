﻿using System;
using System.Collections.Generic;
using System.Text;
using WildApp.Data;

namespace WildApp.Domain
{
    public class FakeAPI
    {
        public async Task<WaterTest> GetFakeWaterData()
        {
            // Simuliert Wartezeit wie bei einer echten REST API
            await Task.Delay(500);

            WaterTest fakeData = new WaterTest
            {
                WaterQuality = 23.5,
                Temperature = 41.2,
                Conductivity = 9999,
                OxygenLevel = 0.8,
                PhValue = 2.1
            };

            return fakeData;
        }

        public async Task<WaterTest> GetRandomWaterData()
        {
            await Task.Delay(500);

            Random random = new Random();

            WaterTest randomData = new WaterTest
            {
                WaterQuality = random.Next(0, 101),
                Temperature = Math.Round(random.NextDouble() * 50, 2),
                Conductivity = random.Next(0, 10000),
                OxygenLevel = Math.Round(random.NextDouble() * 15, 2),
                PhValue = Math.Round(random.NextDouble() * 14, 2)
            };

            return randomData;
        }
    }
}
