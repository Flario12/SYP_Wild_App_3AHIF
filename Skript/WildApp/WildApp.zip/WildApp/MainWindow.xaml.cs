﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using WildApp.Data;
using WildApp.Domain;

namespace WildApp
{
    public partial class MainWindow : Window
    {
        private readonly Controllers controller = new Controllers();
        private readonly WeatherService service = new WeatherService();
        private readonly FakeAPI waterService = new FakeAPI();

        private readonly Dictionary<string, (double lat, double lon)> cities =
            new Dictionary<string, (double lat, double lon)>(StringComparer.OrdinalIgnoreCase)
            {
                { "Dornbirn", (47.41, 9.74) },
                { "Wien", (48.21, 16.37) },
                { "Graz", (47.07, 15.43) },
                { "Linz", (48.31, 14.29) },
                { "Salzburg", (47.80, 13.04) },
                { "Innsbruck", (47.27, 11.40) },
                { "Bregenz", (47.50, 9.75) },
                { "Klagenfurt", (46.62, 14.31) },
                { "St. Pölten", (48.21, 15.62) },
                { "Villach", (46.61, 13.85) },
                { "Wiener Neustadt", (47.81, 16.24) },
                { "Feldkirch", (47.24, 9.60) },
                { "Eisenstadt", (47.85, 16.52) }
            };

        public MainWindow()
        {
            InitializeComponent();
        }

        private bool TryGetCoordinates(out double lat, out double lon)
        {
            lat = 0;
            lon = 0;

            string city = Stadt.Text.Trim();

            if (string.IsNullOrWhiteSpace(city))
            {
                Temperatur.Content = "Bitte Stadt eingeben";
                Wind.Content = "Bitte Stadt eingeben";
                return false;
            }

            if (!cities.ContainsKey(city))
            {
                Temperatur.Content = "Stadt nicht gefunden";
                Wind.Content = "Stadt nicht gefunden";
                return false;
            }

            lat = cities[city].lat;
            lon = cities[city].lon;

            return true;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetCoordinates(out double lat, out double lon))
            {
                return;
            }

            try
            {
                await service.LoadFromAPI(lat, lon);
                Temperatur.Content = $"{service.GetTemperature()} °C";
            }
            catch (Exception ex)
            {
                Temperatur.Content = "Fehler beim Laden";
                MessageBox.Show(ex.Message, "API Fehler");
            }
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (!TryGetCoordinates(out double lat, out double lon))
            {
                return;
            }

            try
            {
                await service.LoadFromAPI(lat, lon);
                Wind.Content = $"{service.GetWind()} km/h";
            }
            catch (Exception ex)
            {
                Wind.Content = "Fehler beim Laden";
                MessageBox.Show(ex.Message, "API Fehler");
            }
        }

        private async void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (!TryGetCoordinates(out double lat, out double lon))
            {
                return;
            }

            try
            {
                var result = await controller.UpdateWeather(lat, lon);

                Temperatur.Content = $"{result.temp} °C";
                Wind.Content = $"{result.wind} km/h";
            }
            catch (Exception ex)
            {
                Temperatur.Content = "Fehler";
                Wind.Content = "Fehler";
                MessageBox.Show(ex.Message, "API Fehler");
            }
        }

        private async void Button_WaterTest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WasserStatus.Content = "Lädt...";

                WaterTest result = await waterService.GetFakeWaterData();

                WasserQualitaet.Content = $"{result.WaterQuality} %";
                WasserTemperatur.Content = $"{result.Temperature} °C";
                Leitfaehigkeit.Content = $"{result.Conductivity}";
                Sauerstoff.Content = $"{result.OxygenLevel} mg/L";
                PhWert.Content = $"{result.PhValue}";
                WasserStatus.Content = result.GetQualityStatus();
            }
            catch (Exception ex)
            {
                WasserStatus.Content = "Fehler";
                MessageBox.Show(ex.Message, "Wasser API Fehler");
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}